package com.project;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Signup")
public class Signup extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        Connection con = null;
        PreparedStatement ps = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "admin");
            ps = con.prepareStatement("INSERT INTO signup (uname, email, pwd) VALUES (?, ?, ?)");

            String uname = req.getParameter("uname");
            String email = req.getParameter("email");
            String pwd = req.getParameter("pwd");
            String cpwd = req.getParameter("cpwd");

            if (pwd.equals(cpwd)) {
                ps.setString(1, uname);
                ps.setString(2, email);
                ps.setString(3, pwd);
                ps.execute();
                RequestDispatcher rs = req.getRequestDispatcher("Signin.jsp");
                rs.include(req, res);
            }
            else {
            	RequestDispatcher rs = req.getRequestDispatcher("Signup.jsp");
                rs.include(req, res);
            }
            }catch(Exception e) {
            	
            }
    }
}
