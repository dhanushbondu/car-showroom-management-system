package com.project;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/BookCarServlet")
@MultipartConfig
public class BookCarServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the car name and image file name
        String carName = request.getParameter("carName");
        String carImagePath = request.getParameter("carImage");

        // Get the username from the session
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");

        if (username == null || carName == null || carImagePath == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        // Load the car image as a BLOB
        InputStream carImageInputStream = getServletContext().getResourceAsStream("/" + carImagePath);

        if (carImageInputStream == null) {
            response.sendRedirect("index.jsp");
            return;
        }

        // Connect to the database and store the car information
        String jdbcURL = "jdbc:mysql://localhost:3306/project";
        String dbUser = "root";
        String dbPassword = "admin";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            String sql = "INSERT INTO CarInfo (car_name, car_image, username) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, carName);
            statement.setBlob(2, carImageInputStream);
            statement.setString(3, username);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                response.sendRedirect("Cars.jsp");
            } else {
                response.sendRedirect("index.jsp");
            }

            connection.close();
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("index.jsp");
        }
    }
}
