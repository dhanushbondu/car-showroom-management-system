package com.project;

import java.io.IOException;
import java.sql.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Signin
 */
public class Signin extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        Connection con = null;

        String uname = req.getParameter("uname");
        String pwd = req.getParameter("pwd");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/project", "root", "admin");
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select * from signup");

            int c = 0;
            while (rs.next()) {
                if ((rs.getString(1).equals(uname)) && (rs.getString(3).equals(pwd))) {
                    c = 1;
                    HttpSession session = req.getSession();
                    session.setAttribute("username", uname);
                    break;
                }
            }
            if (c == 1) {
                RequestDispatcher re = req.getRequestDispatcher("Home.jsp");
                re.forward(req, res);
            } else {
                req.setAttribute("loginFailed", "true");
                RequestDispatcher re = req.getRequestDispatcher("Signin.jsp");
                re.forward(req, res);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
